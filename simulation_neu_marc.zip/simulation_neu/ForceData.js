"use strict";

class ForceData{

	constructor(force, pressure_centre){
		this.force = 0;
		this.pressure_centre = pressure_centre;
	}
	
}
