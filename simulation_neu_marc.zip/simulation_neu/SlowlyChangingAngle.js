"use strict";

class SlowlyChangingAngle extends Actuator{
	
}
