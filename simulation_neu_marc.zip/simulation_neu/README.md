# Simulation

In the simulation folder you find an interactive simulation that runs in your browser.
<br>

<img src="https://github.com/KitesForFuture/powerplant/blob/main/media/simulation.png" width="900" >

* To run simulation, you can visit: https://www.kitesforfuture.de/flight_simulator_37/kite_simulation.html

* To work on the code, copy the whole simulation folder to your PC. Open the kite_simulation.html file with a web browser to run the simulation.
