"use strict";

class BLDCMotor extends Actuator{
	
	constructor(){
		super(300, 0, 90);
	}
	
}
