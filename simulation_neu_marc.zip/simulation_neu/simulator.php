<?php
		// You'd put this code at the top of any "protected" page you create
		//echo $_POST['gamename'];
		
		// Always start this first
		session_start();
		
		if ( isset( $_SESSION['user_id'] ) && isset($_SESSION['user_group']) && ($_SESSION['user_group'] == 'controller' || $_SESSION['user_group'] == 'viewer' )) {
			// Grab user data from the database using the user_id
			// Let them access the "logged in only" pages
			
			
			if ( ! empty( $_GET ) ) {
				if ( isset( $_GET['ID'] ) && isset( $_GET['command'] )) {
					//header("Location: https://www.isomathe.de/code/v6.11/commandKite.php?name=".$_POST['kitename']."&command=".$_POST['command']);
					
					//write command to db
					$servername = "dedivirt2155.your-server.de";
					$login = "dedivirk_2_w";
					$password = "ae0wt62IC68ZNxk2";
					$database = "kites_db";
					$table = "kites";
					
					$con = mysqli_connect($servername, $login, $password, $database);
					if (!$con) {
						die('Could not connect: ' . mysqli_error($con));
					}

					mysqli_select_db($con,$database);
					//write to DB
					$sql = "UPDATE `kites` SET `command`='".$_GET['command']."' WHERE `ID`='".$_GET['ID']."'";
					$result = mysqli_query($con,$sql);
				}
			}
			
			
			
			//get name of games:
			$servername = "dedivirt2155.your-server.de";
			$login = "dedivirk_2_r";
			$password = "gyC7ZX3xl8JS6XBc";
			$database = "kites_db";
			$table = "kites";
			
			$con = mysqli_connect($servername, $login, $password, $database);
			if (!$con) {
				die('Could not connect: ' . mysqli_error($con));
			}

			mysqli_select_db($con,$database);

			$sql="SELECT * FROM ".$table." WHERE 1";
			$result = mysqli_query($con,$sql);
			$i = 0;
			while($row = mysqli_fetch_assoc($result)){
				$kiteID[$i] = $row['ID'];
				$kiteName[$i] = $row['name'];
				$kiteStatus[$i] = $row['status'];
				$kiteStatusTime[$i] = $row['datetime'];
				$kiteCommand[$i] = $row['command'];
				$kiteLineLength[$i] = $row['line_length'];
				$i = $i+1;
			}
			
			
			
			
			$text= file_get_contents('simulator.html');
			echo $text;
		} else {
			// TODO: Redirect them to the login page
			echo "Nothing to see here";
		}
		?>


