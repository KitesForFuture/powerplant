"use strict";

class ControlData{

	constructor(left_prop, right_prop, left_elevon, right_elevon, left_aileron, right_aileron, rudder, line_tension){
		this.left_prop = left_prop;
		this.right_prop = right_prop;
		this.left_elevon = left_elevon;
		this.right_elevon = right_elevon;
		this.left_aileron = left_aileron;
		this.right_aileron = right_aileron;
		this.rudder = rudder;
		this.line_tension = line_tension;
	}
	
}
