"use strict";

const HOVER_MODE = 0;
const EIGHT_MODE = 1;
const TRANSITION_MODE = 2;
const STRAIGHT_MODE = 3;
const LANDING_MODE = 4;
const LANDING_MODE_HOVER = 5;
const LANDING_EIGHT_TRANSITION = 6;
const FINAL_LANDING_MODE = 7;
const FINAL_LANDING_MODE_HOVER = 8;


const FIRST_TURN_MULTIPLIER = 0.5;

const LEFT = 0;
const RIGHT = 1;

class Autopilot{
	
	loadConfigVariables(config_values){
		this.hover.Y.P = config_values[14];
		this.hover.Y.D = config_values[15];
		
		this.hover.Z.P = config_values[17];
		this.hover.Z.D = config_values[18];
		
		this.hover.X.D = config_values[19];
		
		this.hover.H.P = config_values[20];
		this.hover.H.D = config_values[21];
		this.hover.y_angle_offset = config_values[16]*PI/180;
		this.transition_y_angle_offset = config_values[31]*PI/180;
		this.eight.Y.D = config_values[29];
		
		this.eight.Z.P = config_values[27];
		this.eight.Z.D = config_values[28];
		this.eight.roll.P = config_values[42];
		this.eight.roll.D = config_values[43];
		
		this.landing.X.P = config_values[25];
		this.landing.X.D = config_values[44];
		this.landing.roll.P = config_values[45];
		this.landing.roll.D = config_values[46];
		this.landing.Y.P = config_values[23];
		this.landing.Y.D = config_values[24];
		this.landing.desired_height = config_values[26];
		
		this.brake = config_values[22];
		this.sideways_flying_time = config_values[12];
		this.turning_speed = config_values[13]*PI/180;
		
		
		this.eight.elevator = config_values[30];
		this.eight.desired_line_angle_from_zenith = PI/2-config_values[32]*PI/180;
		this.eight.target_angle_beta_clamp = config_values[33];
		this.eight.beta_P = config_values[34];
		this.eight.neutral_beta_sideways_flying_angle_fraction = config_values[35];
		this.landing.dive_angle_P = config_values[36];
	}
	
	constructor(){
		
		this.hover = new Object();
		
		this.hover.Y = new Object();
		this.hover.Y.P = 1;
		this.hover.Y.D = 1;
		
		this.hover.Z = new Object();
		this.hover.Z.P = 4.8;
		this.hover.Z.D = 3.7;
		
		this.hover.X = new Object();
		this.hover.X.D = 1;
		
		this.hover.H = new Object();
		this.hover.H.P = 1;
		this.hover.H.D = 1;
		
		this.eight = new Object();
		this.eight.Z = new Object();
		this.eight.roll = new Object();
		this.eight.Z.P = 1.3;
		this.eight.Z.D = 2.86;
		this.eight.roll.P = 4.8;
		this.eight.roll.D = 1.7;
		this.eight.desired_line_angle_from_zenith = 60*Math.PI/180;
		this.eight.beta_P = 1;
		this.eight.Y = new Object();
		this.eight.Y.D = 0.02;
		this.eight.elevator = 5*Math.PI/180;
		this.eight.target_angle_beta_clamp = 0.4;
		this.landing = new Object();
		this.landing.X = new Object();
		this.landing.roll = new Object();
		this.landing.roll.P = 1;
		this.landing.roll.D = 1;
		this.landing.X.P = 1;
		this.landing.X.D = 1;
		this.landing.Y = new Object();
		this.landing.Y.P = 0.35;
		this.landing.Y.D = 0.000001;
		this.landing.desired_height = 0;
		this.eight.neutral_beta_sideways_flying_angle_fraction = 0.9;
		this.y_angle_offset = 0.1;
		this.desired_height = 0;
		
		this.figure_eight = new Object(); // ...
		
		this.mode = HOVER_MODE;
		this.direction = 1;
		this.sideways_flying_time = 7;
		
		this.multiplier = FIRST_TURN_MULTIPLIER;
		this.turning_speed = 2.5;//1.3;//0.75;//0.75;
		this.slowly_changing_target_angle = new SlowlyChangingAngle(this.turning_speed, -1000, 1000);
		
		this.old_line_length = 0;
		this.smooth_reel_in_speed = 0.1;
		
		this.qr_neutral = 15;
		
		this.timer = new AsyncTimer();
		
		this.target_angle = 0;
		this.desired_dive_angle = 0;
		this.desired_dive_angle_smooth = 0;
		
		
		this.leftKeyPressed = false;
		this.rightKeyPressed = false;
		
		this.motor_I = 0;
	}
	
	step(sensor_data, line_length, line_tension, timestep_in_s){
		advanceGlobalTime(timestep_in_s);
		
		if(lineAttached){
			return this.eight_control(sensor_data, line_length, timestep_in_s);
		}else{
			return this.horizontalflug(sensor_data, line_length, line_tension, true);
		}
	}
	
	eight_control(sensor_data, line_length, timestep_in_s){
		
		if(this.timer.timeElapsedInSeconds() > this.sideways_flying_time * this.multiplier){ // IF TIME TO TURN
			//TURN
			console.log("turn");
			this.direction  *= -1;
			this.multiplier = 1;
			this.timer.reset();
		}
		
		var mat = sensor_data.rotation_matrix.elements;
		var mat_line = sensor_data.rotation_matrix_line.elements;
		
		// ACCURATE LINE ANGLE FROM LINE ANGLE SENSOR
		let z_axis_angle_from_zenith = acos_clamp(mat_line[6]);
		
		// ACCURATE (for low pitch angles) ROLL ANGLE w.r.t. KITE LINE
		let line_vector = new THREE.Vector3(mat_line[6], mat_line[7], mat_line[8]);
		let wing_direction = new THREE.Vector3(mat[3], mat[4], mat[5]);
		let roll_angle = angle(line_vector, wing_direction) - Math.PI*0.5;
		
		
		// 1. STAGE P(I)D: line angle -> flight direction
		let angle_diff = this.eight.desired_line_angle_from_zenith - z_axis_angle_from_zenith;
		let target_angle_adjustment = clamp(angle_diff*this.eight.beta_P, -this.eight.target_angle_beta_clamp, this.eight.target_angle_beta_clamp);  // 3 works well for line angle control, but causes instability. between -pi/4=-0.7... and pi/4=0.7...
		this.target_angle = Math.PI*0.5*this.direction*(this.eight.neutral_beta_sideways_flying_angle_fraction + target_angle_adjustment/* 1 means 1.2*90 degrees, 0 means 0 degrees*/);
		this.slowly_changing_target_angle.setTargetValue(this.target_angle);
		this.slowly_changing_target_angle.step(timestep_in_s);
		let slowly_changing_target_angle = this.slowly_changing_target_angle.getValue();//(target_angle, this.turning_speed);
		
		// 2. STAGE P(I)D: flight direction -> neccessary roll angle
		// TODO: need new config values for this controller
		var z_axis_offset = this.getAngleError(0.0, new THREE.Vector3(mat[6], mat[7], mat[8]), new THREE.Vector3(mat[3], mat[4], mat[5]));
		z_axis_offset -= slowly_changing_target_angle;
		let desired_roll_angle = clamp(this.eight.roll.P * z_axis_offset - this.eight.roll.D * sensor_data.gyro.z, -60*Math.PI/180, 60*Math.PI/180);
		
		desired_roll_angle = this.leftKeyPressed * 0.8 - this.rightKeyPressed * 0.8;//clamp(this.landing.roll.P * angle_error - this.landing.roll.D * sensor_data.gyro.z, -80*Math.PI/180, 80*Math.PI/180);
		
		
		
		// 3. STAGE P(I)D: neccessary roll angle -> aileron deflection
		var z_axis_control = - 150 * (desired_roll_angle-roll_angle) - 5 * sensor_data.gyro.x;//- 0.56 * this.eight.Z.P * (desired_roll_angle-roll_angle) - 0.22 * this.eight.Z.D * sensor_data.gyro.x;
		
		console.log("angle_diff = " + angle_diff + ", z_axis_offset = " + z_axis_offset + ", desired_roll_angle = " + desired_roll_angle + ", roll_angle = " + roll_angle + ", z_axis_control = " + z_axis_control);
		
		/*
		//let z_axis_angle = acos_clamp(mat[6]); // roll angle of kite = line angle
		let z_axis_angle_from_zenith = acos_clamp(1.4*sensor_data.height/(line_length == 0 ? 1.0 : line_length)); //safe_acos(mat[6]); // roll angle of kite = line angle
		// TODO: This causes less waves between curves! Maybe combine both!
		//let z_axis_angle_from_zenith = acos_clamp(mat[6]); // roll angle of kite = line angle
		
		//this.loggingString = "Seilwinkel = " + (90 - z_axis_angle *180 / Math.PI).toFixed(0) + " deg<br>"
		//let RC_requested_line_angle = Math.PI/4 * 1.3;//1.85;// 1.5; // TODO: rename line_angle
		//this.loggingString += "Sollseilwinkel = " + (90 - RC_requested_line_angle *180 / Math.PI).toFixed(0) + " deg<br>"
		let angle_diff = this.eight.desired_line_angle_from_zenith - z_axis_angle_from_zenith;
		//float target_angle_adjustment = clamp(angle_diff*autopilot->eight.beta_P, -autopilot->eight.target_angle_beta_clamp, autopilot->eight.target_angle_beta_clamp);
		let target_angle_adjustment = clamp(angle_diff*this.eight.beta_P, -this.eight.target_angle_beta_clamp, this.eight.target_angle_beta_clamp); // 3 works well for line angle control, but causes instability. between -pi/4=-0.7... and pi/4=0.7...
		//this.loggingString += "clamp(angle_diff * 0.5) = " + target_angle_adjustment.toFixed(3) + "<br>";
		//let sideways_flying_angle_fraction =this.eight.neutral_beta_sideways_flying_angle_fraction;//0.9;//0.75; // fraction of 90 degrees, this influences the angle to the horizon, smaller => greater angle = flying higher
		//console.log(this.eight.neutral_beta_sideways_flying_angle_fraction);
		this.target_angle = Math.PI*0.5*this.direction*(this.eight.neutral_beta_sideways_flying_angle_fraction + target_angle_adjustment);
		//this.loggingString += "target_angle = " + (this.target_angle * 180 / Math.PI).toFixed(0) + " deg<br>";
		this.slowly_changing_target_angle.setTargetValue(this.target_angle);
		this.slowly_changing_target_angle.step(timestep_in_s);
		let slowly_changing_target_angle = this.slowly_changing_target_angle.getValue();//(target_angle, this.turning_speed);
		
		var z_axis_offset = this.getAngleError(0.0, new THREE.Vector3(mat[6], mat[7], mat[8]), new THREE.Vector3(mat[3], mat[4], mat[5]));
		z_axis_offset -= slowly_changing_target_angle;
		
		var z_axis_control = - 0.56 * this.eight.Z.P * z_axis_offset + 0.22 * this.eight.Z.D * sensor_data.gyro.z - 1 * this.eight.Z.D2 * sensor_data.gyro.x;
		*/
		
		z_axis_control *=100;
		z_axis_control = clamp(0.5*z_axis_control, -15, 15);
		var y_axis_control = this.eight.elevator*180/Math.PI - this.eight.Y.D * sensor_data.gyro.y;
		//console.log("y_axis_control = " + y_axis_control + ", z_axis_control = " + z_axis_control);
		return new ControlData(0, 0,
			y_axis_control,
			y_axis_control,
			- z_axis_control + Math.abs(z_axis_control)*0.5,
			+ z_axis_control + Math.abs(z_axis_control)*0.5,
			0,
			35);
	}
	
	
	horizontalflug(sensor_data, line_length, line_tension, transition){
		
		
		let height = sensor_data.height-this.landing.desired_height;
		let height_error = height - 10;
		let desired_dive_angle = 0.3*height_error;//-desired_line_angle - 2.0 * line_angle_error;
		
		//this.desired_dive_angle_smooth = desired_dive_angle;
		desired_dive_angle = clamp( desired_dive_angle, -Math.PI/8, Math.PI/8 );
		
		
		
		var mat = sensor_data.rotation_matrix.elements;
		var mat_line = sensor_data.rotation_matrix_line.elements;
		
		let y_axis_offset = this.getAngleError(-desired_dive_angle - Math.PI/2, new THREE.Vector3(mat[3], mat[4], mat[5]), new THREE.Vector3(-mat[6], -mat[7], -mat[8]));
		let y_axis_control =  (- 70 * y_axis_offset + 7 * 0.5 * 0.66 * this.landing.Y.D * sensor_data.gyro.y);
		
		//console.log("y_control = " + y_axis_control + ", y_offset = " + y_axis_offset + ", desired_dive_angle = " + this.desired_dive_angle_smooth + ", height_error = " + height_error + ", desired_dive_angle = " + desired_dive_angle);
		
		let angle_error = angle(new THREE.Vector3(mat[4], mat[5], 0), new THREE.Vector3(mat_line[7], mat_line[8], 0)) - Math.PI*0.5 + this.leftKeyPressed * 0.5 - this.rightKeyPressed * 0.5;
		
		
		
		let desired_roll_angle = this.leftKeyPressed * 1.3 - this.rightKeyPressed * 1.3;//clamp(this.landing.roll.P * angle_error - this.landing.roll.D * sensor_data.gyro.z, -80*Math.PI/180, 80*Math.PI/180);
		//console.log("angle_error = " + angle_error + ", desired_roll_angle = " + desired_roll_angle);
		let roll_angle = asin_clamp(- mat[3]);
		var x_axis_control = - this.leftKeyPressed * 30 + this.rightKeyPressed * 30;//
		
		x_axis_control = clamp(x_axis_control, -15, 15);
		y_axis_control = clamp(y_axis_control, -45, 45);
		
		let leftElevon = y_axis_control;
		let rightElevon = y_axis_control;
		
		let leftAileron = -1*x_axis_control + Math.abs(x_axis_control)*0.0 + 5;
		let rightAileron = 1*x_axis_control + Math.abs(x_axis_control)*0.0 + 5;
		
		//console.log("y_axis_control = " + y_axis_control + "x_axis_control = " + x_axis_control + ", leftAileron = " + leftAileron + ", rightAileron = " + rightAileron);
		
		let intended_speed = 75 / 3.6;
		
		if(sensor_data.speed - intended_speed < 0){
			this.motor_I += 0.1;
		}else{
			this.motor_I -= 0.1;
		}
		this.motor_I = clamp(this.motor_I, 0, 45);
		
		let thrust = this.motor_I - 20 * (sensor_data.speed - intended_speed);
		
		thrust = clamp(thrust, 0, 90);
		
		console.log("thrust = " + thrust + ", motorI = " + this.motor_I);
		
		return new ControlData(thrust, thrust,
		leftElevon,
		rightElevon,
		leftAileron,
		rightAileron, 0, 2);
	}
	
	
	getAngleError(offset, controllable_axis/*vector*/, axis_we_wish_horizontal/*vector*/){
		var where_axis_we_wish_horizontal_should_be = controllable_axis.clone().cross(new THREE.Vector3(1,0,0));
		
		if(where_axis_we_wish_horizontal_should_be < 0.05){ // close to undefinedness
			return 0;
		}else{
			where_axis_we_wish_horizontal_should_be.normalize();
			return Math.sign(axis_we_wish_horizontal.x) * angle(axis_we_wish_horizontal, where_axis_we_wish_horizontal_should_be) - offset;
		}
	}
}
